<?php


namespace App\classes;


class FullName
{

}