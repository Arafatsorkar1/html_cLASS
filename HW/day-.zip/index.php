<?php
require_once 'vendor/autoload.php';
use App\classes\HomePage;


$homepage = new HomePage();
$homepage->index();