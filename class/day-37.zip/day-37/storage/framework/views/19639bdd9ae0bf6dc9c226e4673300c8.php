<?php $__env->startSection('title'); ?>

    home

<?php $__env->stopSection(); ?>


<?php $__env->startSection('body'); ?>



















<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\xampp\htdocs\laravel\day-37\resources\views/home/home.blade.php ENDPATH**/ ?>